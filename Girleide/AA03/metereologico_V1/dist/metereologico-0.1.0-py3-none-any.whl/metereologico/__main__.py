from _interface import Interface

def main():
    wid = Interface()
    wid.interface()

if __name__ == "__main__":
    main()
